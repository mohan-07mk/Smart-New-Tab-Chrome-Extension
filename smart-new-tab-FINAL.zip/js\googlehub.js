/* =============================================
   GOOGLEHUB.JS — Google Products Panel
   ============================================= */

const GoogleHub = (() => {
  const GOOGLE_SERVICES = [
    { name: 'Gmail',      url: 'https://mail.google.com',          emoji: '📧' },
    { name: 'Drive',      url: 'https://drive.google.com',         emoji: '📁' },
    { name: 'Docs',       url: 'https://docs.google.com',          emoji: '📄' },
    { name: 'Sheets',     url: 'https://sheets.google.com',        emoji: '📊' },
    { name: 'Slides',     url: 'https://slides.google.com',        emoji: '📽️' },
    { name: 'Calendar',   url: 'https://calendar.google.com',      emoji: '📅' },
    { name: 'Meet',       url: 'https://meet.google.com',          emoji: '🎥' },
    { name: 'Photos',     url: 'https://photos.google.com',        emoji: '🖼️' },
    { name: 'YouTube',    url: 'https://youtube.com',              emoji: '▶️' },
    { name: 'Maps',       url: 'https://maps.google.com',          emoji: '🗺️' },
    { name: 'Translate',  url: 'https://translate.google.com',     emoji: '🌐' },
    { name: 'News',       url: 'https://news.google.com',          emoji: '📰' },
  ];

  const panel = document.getElementById('google-hub-panel');
  const gridEl = document.getElementById('google-services-grid');
  const openBtn = document.getElementById('btn-google-hub');
  const closeBtn = document.getElementById('close-google-hub');

  function render() {
    if (!gridEl) return;
    gridEl.innerHTML = GOOGLE_SERVICES.map(s => `
      <a href="${s.url}" target="_blank" rel="noopener" class="gs-card">
        <span class="gs-icon">${s.emoji}</span>
        <span class="gs-name">${s.name}</span>
      </a>
    `).join('');
  }

  function open() {
    if (panel) panel.classList.remove('hidden');
    render();
  }

  function close() {
    if (panel) panel.classList.add('hidden');
  }

  function init() {
    if (openBtn) openBtn.addEventListener('click', open);
    if (closeBtn) closeBtn.addEventListener('click', close);
    if (panel) panel.addEventListener('click', e => { if (e.target === panel) close(); });
  }

  return { init };
})();

window.GoogleHub = GoogleHub;
