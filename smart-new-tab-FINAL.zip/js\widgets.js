/* =============================================
   WIDGETS.JS — Widget Visibility + Drag-to-Reorder
   ============================================= */

const Widgets = (() => {
  const WIDGET_LABELS = {
    clock: '🕐 Clock',
    weather: '🌤 Weather',
    pomodoro: '🍅 Pomodoro',
    timer: '⏱ Timer',
    todo: '✅ To-Do List',
    water: '💧 Water Reminder',
  };

  let widgetState = {
    clock: true, weather: true, pomodoro: true,
    timer: true, todo: true, water: true,
  };

  let widgetOrder = ['clock','weather','pomodoro','timer','todo','water'];

  async function save() {
    await Storage.set({ widgets: widgetState, widgetOrder });
  }

  function applyState() {
    Object.entries(widgetState).forEach(([id, visible]) => {
      const el = document.getElementById(`widget-${id}`);
      if (el) el.style.display = visible ? '' : 'none';
    });
  }

  function applyOrder() {
    const grid = document.getElementById('widgets-grid');
    if (!grid) return;
    widgetOrder.forEach(id => {
      const el = document.getElementById(`widget-${id}`);
      if (el) grid.appendChild(el);
    });
  }

  function renderToggles() {
    const container = document.getElementById('widget-toggles');
    if (!container) return;
    container.innerHTML = '';
    Object.entries(WIDGET_LABELS).forEach(([id, label]) => {
      const row = document.createElement('div');
      row.className = 'widget-toggle-row';
      const toggle = document.createElement('div');
      toggle.className = 'toggle-switch' + (widgetState[id] ? ' on' : '');
      toggle.id = `toggle-${id}`;
      toggle.addEventListener('click', async () => {
        widgetState[id] = !widgetState[id];
        toggle.classList.toggle('on', widgetState[id]);
        applyState();
        await save();
      });
      row.innerHTML = `<span>${label}</span>`;
      row.appendChild(toggle);
      container.appendChild(row);
    });
  }

  function initDrag() {
    const grid = document.getElementById('widgets-grid');
    if (!grid) return;
    let dragSrc = null;

    grid.querySelectorAll('.widget').forEach(widget => {
      const handle = widget.querySelector('.widget-drag-handle');
      if (handle) {
        handle.addEventListener('mousedown', () => { widget.draggable = true; });
        handle.addEventListener('mouseup', () => { widget.draggable = false; });
      }

      widget.addEventListener('dragstart', (e) => {
        dragSrc = widget;
        widget.classList.add('dragging-widget');
        grid.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      widget.addEventListener('dragend', () => {
        widget.classList.remove('dragging-widget');
        grid.classList.remove('dragging');
        grid.querySelectorAll('.drag-over-widget').forEach(el => el.classList.remove('drag-over-widget'));
        dragSrc = null;
      });
      widget.addEventListener('dragover', (e) => {
        e.preventDefault(); e.dataTransfer.dropEffect = 'move';
        if (widget !== dragSrc) widget.classList.add('drag-over-widget');
      });
      widget.addEventListener('dragleave', () => widget.classList.remove('drag-over-widget'));
      widget.addEventListener('drop', async (e) => {
        e.preventDefault();
        if (!dragSrc || dragSrc === widget) return;
        widget.classList.remove('drag-over-widget');
        const allWidgets = [...grid.querySelectorAll('.widget')];
        const srcIdx = allWidgets.indexOf(dragSrc);
        const dstIdx = allWidgets.indexOf(widget);
        if (srcIdx < dstIdx) grid.insertBefore(dragSrc, widget.nextSibling);
        else grid.insertBefore(dragSrc, widget);
        // Update order
        const newOrder = [...grid.querySelectorAll('.widget')].map(el => el.dataset.widget);
        widgetOrder = newOrder;
        await save();
        window.showToast('Widget order saved.');
      });
    });
  }

  async function init() {
    const r = await Storage.get(['widgets', 'widgetOrder']);
    if (r.widgets) widgetState = { ...widgetState, ...r.widgets };
    if (r.widgetOrder && r.widgetOrder.length) widgetOrder = r.widgetOrder;
    applyOrder();
    applyState();
    initDrag();

    // Close buttons
    document.querySelectorAll('.widget-close-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const widgetId = btn.dataset.widget;
        if (widgetId) {
          widgetState[widgetId] = false;
          applyState();
          await save();
          window.showToast(`${WIDGET_LABELS[widgetId]} hidden. Re-enable in Settings.`);
        }
      });
    });
  }

  return { init, renderToggles, widgetState };
})();

window.Widgets = Widgets;
