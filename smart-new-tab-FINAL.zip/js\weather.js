/* =============================================
   WEATHER.JS — Live Weather Widget
   ============================================= */

const Weather = (() => {
  let unit = 'metric'; // metric = °C, imperial = °F
  let apiKey = 'YOUR_OPENWEATHERMAP_API_KEY';
  let currentData = null;

  const contentEl = document.getElementById('weather-content');
  const unitBtn = document.getElementById('weather-unit-toggle');

  const WEATHER_ICONS = {
    '01d': '☀️', '01n': '🌙',
    '02d': '⛅', '02n': '⛅',
    '03d': '☁️', '03n': '☁️',
    '04d': '☁️', '04n': '☁️',
    '09d': '🌧️', '09n': '🌧️',
    '10d': '🌦️', '10n': '🌧️',
    '11d': '⛈️', '11n': '⛈️',
    '13d': '❄️', '13n': '❄️',
    '50d': '🌫️', '50n': '🌫️',
  };

  function getIcon(code) { return WEATHER_ICONS[code] || '🌤'; }

  function renderLoading() {
    if (!contentEl) return;
    contentEl.innerHTML = '<div class="weather-loading">📍 Detecting location...</div>';
  }

  function renderError(msg) {
    if (!contentEl) return;
    contentEl.innerHTML = `<div class="weather-error">⚠️ ${msg}</div>
      <div style="text-align:center; margin-top:8px">
        <small style="opacity:0.6">Add OpenWeatherMap API key in Settings</small>
      </div>`;
  }

  function renderWeather(data) {
    if (!contentEl) return;
    const temp = Math.round(data.main.temp);
    const feels = Math.round(data.main.feels_like);
    const icon = getIcon(data.weather[0].icon);
    const unitSymbol = unit === 'metric' ? '°C' : '°F';

    contentEl.innerHTML = `
      <div class="weather-main">
        <div class="weather-icon">${icon}</div>
        <div>
          <div class="weather-temp">${temp}${unitSymbol}</div>
          <div class="weather-city">${data.name}, ${data.sys.country}</div>
          <div class="weather-desc">${data.weather[0].description}</div>
        </div>
      </div>
      <div class="weather-details">
        <span class="weather-detail-item">💧 ${data.main.humidity}%</span>
        <span class="weather-detail-item">💨 ${Math.round(data.wind.speed)} ${unit === 'metric' ? 'm/s' : 'mph'}</span>
        <span class="weather-detail-item">🌡️ Feels ${feels}${unitSymbol}</span>
        <span class="weather-detail-item">👁️ ${(data.visibility / 1000).toFixed(1)} km</span>
      </div>
    `;
  }

  async function fetchWeather(lat, lon) {
    if (!apiKey || apiKey === 'YOUR_OPENWEATHERMAP_API_KEY') {
      renderError('Set your OpenWeatherMap API key in Settings to see live weather.');
      return;
    }
    try {
      const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=${unit}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('API error: ' + res.status);
      currentData = await res.json();
      renderWeather(currentData);
    } catch (err) {
      renderError('Could not load weather. Check your API key.');
      console.error('[Weather]', err);
    }
  }

  function getLocation() {
    renderLoading();
    if (!navigator.geolocation) {
      renderError('Geolocation not supported.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        Storage.set({ weatherLocation: { lat: pos.coords.latitude, lon: pos.coords.longitude } });
        fetchWeather(pos.coords.latitude, pos.coords.longitude);
      },
      () => {
        // Fallback: free IP-based location
        fetch('https://ipapi.co/json/')
          .then(r => r.json())
          .then(d => fetchWeather(d.latitude, d.longitude))
          .catch(() => renderError('Location access denied.'));
      },
      { timeout: 8000, maximumAge: 600000 }
    );
  }

  async function init() {
    const r = await Storage.get(['weatherUnit', 'weatherApiKey', 'weatherLocation']);
    unit = r.weatherUnit || 'metric';
    apiKey = r.weatherApiKey || 'YOUR_OPENWEATHERMAP_API_KEY';
    if (unitBtn) unitBtn.textContent = unit === 'metric' ? '°C' : '°F';

    if (r.weatherLocation) {
      fetchWeather(r.weatherLocation.lat, r.weatherLocation.lon);
    } else {
      getLocation();
    }

    // Refresh every 10 min
    setInterval(() => {
      Storage.get(['weatherLocation', 'weatherApiKey']).then(r2 => {
        apiKey = r2.weatherApiKey || apiKey;
        if (r2.weatherLocation) fetchWeather(r2.weatherLocation.lat, r2.weatherLocation.lon);
      });
    }, 600000);

    // Unit toggle
    if (unitBtn) {
      unitBtn.addEventListener('click', async () => {
        unit = unit === 'metric' ? 'imperial' : 'metric';
        unitBtn.textContent = unit === 'metric' ? '°C' : '°F';
        await Storage.set({ weatherUnit: unit });
        if (currentData) renderWeather(currentData);
        else {
          const r2 = await Storage.get(['weatherLocation']);
          if (r2.weatherLocation) fetchWeather(r2.weatherLocation.lat, r2.weatherLocation.lon);
        }
      });
    }
  }

  function updateApiKey(key) {
    apiKey = key;
    getLocation();
  }

  return { init, updateApiKey };
})();

window.Weather = Weather;
