/* =============================================
   WATER.JS — Water Reminder Widget
   ============================================= */

const Water = (() => {
  let count = 0;
  let goal = 8;
  let interval = 30; // minutes
  let nextReminder = null;
  let alarmTimeout = null;

  const glassesEl = document.getElementById('water-glasses');
  const progressEl = document.getElementById('water-progress-text');
  const drinkBtn = document.getElementById('water-drink-btn');
  const resetBtn = document.getElementById('water-reset-btn');
  const intervalSelect = document.getElementById('water-interval');
  const nextEl = document.getElementById('water-next');

  function render() {
    if (!glassesEl) return;
    glassesEl.innerHTML = '';
    for (let i = 0; i < goal; i++) {
      const glass = document.createElement('span');
      glass.className = 'water-glass' + (i < count ? ' filled' : '');
      glass.textContent = '💧';
      glassesEl.appendChild(glass);
    }
    if (progressEl) progressEl.textContent = `${count} / ${goal} glasses`;
  }

  function scheduleReminder() {
    if (alarmTimeout) clearTimeout(alarmTimeout);
    const ms = interval * 60 * 1000;
    nextReminder = new Date(Date.now() + ms);
    updateNextText();
    alarmTimeout = setTimeout(() => {
      Notifications.fireNotification(
        '💧 Drink Water!',
        `You've had ${count}/${goal} glasses today. Stay hydrated!`,
        'water'
      );
      window.showToast('💧 Time to drink water!');
      scheduleReminder();
    }, ms);

    // Also register with Chrome alarms if available
    if (typeof chrome !== 'undefined' && chrome.alarms) {
      chrome.alarms.create('water-reminder', { delayInMinutes: interval });
    }
  }

  function updateNextText() {
    if (!nextEl || !nextReminder) return;
    const diff = Math.round((nextReminder - Date.now()) / 60000);
    nextEl.textContent = `Next reminder: in ~${diff} min`;
  }

  async function save() {
    await Storage.set({ waterCount: count, waterInterval: interval });
  }

  function checkDailyReset() {
    const today = new Date().toDateString();
    Storage.get(['waterLastReset', 'waterCount']).then(r => {
      if (r.waterLastReset !== today) {
        count = 0;
        Storage.set({ waterCount: 0, waterLastReset: today });
      } else {
        count = r.waterCount || 0;
      }
      render();
    });
  }

  async function init() {
    const r = await Storage.get(['waterCount', 'waterGoal', 'waterInterval', 'waterLastReset']);
    goal = r.waterGoal || 8;
    interval = r.waterInterval || 30;
    if (intervalSelect) intervalSelect.value = String(interval);

    // Daily reset check
    const today = new Date().toDateString();
    if (r.waterLastReset !== today) {
      count = 0;
      await Storage.set({ waterCount: 0, waterLastReset: today });
    } else {
      count = r.waterCount || 0;
    }

    render();
    scheduleReminder();

    if (drinkBtn) {
      drinkBtn.addEventListener('click', async () => {
        if (count < goal) {
          count++;
          await save();
          render();
          if (count === goal) {
            window.showToast('🎉 Daily water goal reached!');
            Notifications.fireNotification('Hydration Goal!', 'You reached your daily water goal! 🎉', 'water');
          }
        }
      });
    }

    if (resetBtn) {
      resetBtn.addEventListener('click', async () => {
        count = 0;
        await Storage.set({ waterCount: 0, waterLastReset: new Date().toDateString() });
        render();
      });
    }

    if (intervalSelect) {
      intervalSelect.addEventListener('change', async () => {
        interval = parseInt(intervalSelect.value);
        await Storage.set({ waterInterval: interval });
        scheduleReminder();
      });
    }

    // Update "next reminder" text every minute
    setInterval(updateNextText, 60000);
  }

  return { init };
})();

window.Water = Water;
