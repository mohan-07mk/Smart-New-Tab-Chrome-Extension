/* =============================================
   AITOOLS.JS — AI Tools Section
   ============================================= */

const AITools = (() => {
  let tools = [];
  let editingId = null;

  const gridEl = document.getElementById('aitools-grid');
  const modal = document.getElementById('aitool-modal');
  const modalTitle = document.getElementById('aitool-modal-title');
  const nameInput = document.getElementById('aitool-name');
  const urlInput = document.getElementById('aitool-url');
  const emojiInput = document.getElementById('aitool-emoji');
  const saveBtn = document.getElementById('aitool-save-btn');
  const addBtn = document.getElementById('btn-add-aitool');
  const closeBtn = document.getElementById('close-aitool-modal');

  const TOOL_COLORS = {
    ChatGPT: 'linear-gradient(135deg, #10a37f, #1a7f64)',
    Gemini:  'linear-gradient(135deg, #4285f4, #a142f4)',
    Perplexity: 'linear-gradient(135deg, #20b2aa, #1a8a83)',
    Grammarly: 'linear-gradient(135deg, #15c39a, #0ea882)',
    'Notion AI': 'linear-gradient(135deg, #ffffff22, #ffffff11)',
    Claude: 'linear-gradient(135deg, #cc785c, #b06040)',
  };

  function genId() { return 'ai' + Date.now() + Math.random().toString(36).slice(2,7); }
  async function save() { await Storage.set({ aiTools: tools }); }

  function escHtml(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  function render() {
    if (!gridEl) return;
    gridEl.innerHTML = '';

    tools.forEach(tool => {
      const card = document.createElement('a');
      card.href = tool.url;
      card.target = '_blank';
      card.className = 'aitool-card';
      card.rel = 'noopener';

      const grad = TOOL_COLORS[tool.name] || 'linear-gradient(135deg, rgba(99,102,241,0.3), rgba(139,92,246,0.3))';
      card.style.background = grad;

      card.innerHTML = `
        <div class="aitool-icon">${tool.emoji || '🤖'}</div>
        <div class="aitool-name">${escHtml(tool.name)}</div>
        <div class="aitool-actions">
          <button class="sc-action-btn ai-edit" data-id="${tool.id}" title="Edit">✏</button>
          <button class="sc-action-btn ai-del" data-id="${tool.id}" title="Delete">✕</button>
        </div>
      `;

      card.querySelectorAll('.ai-edit, .ai-del').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault(); e.stopPropagation();
          if (btn.classList.contains('ai-edit')) openEdit(tool.id);
          else deleteTool(tool.id);
        });
      });

      gridEl.appendChild(card);
    });
  }

  function openAdd() {
    editingId = null;
    if (modalTitle) modalTitle.textContent = 'Add AI Tool';
    if (nameInput) nameInput.value = '';
    if (urlInput) urlInput.value = '';
    if (emojiInput) emojiInput.value = '';
    if (modal) modal.classList.remove('hidden');
    nameInput?.focus();
  }

  function openEdit(id) {
    const tool = tools.find(t => t.id === id);
    if (!tool) return;
    editingId = id;
    if (modalTitle) modalTitle.textContent = 'Edit AI Tool';
    if (nameInput) nameInput.value = tool.name;
    if (urlInput) urlInput.value = tool.url;
    if (emojiInput) emojiInput.value = tool.emoji || '';
    if (modal) modal.classList.remove('hidden');
    nameInput?.focus();
  }

  function closeModal() { if (modal) modal.classList.add('hidden'); }

  async function saveTool() {
    const name = nameInput?.value.trim();
    let url = urlInput?.value.trim();
    const emoji = emojiInput?.value.trim();
    if (!name || !url) { window.showToast('Name and URL are required.'); return; }
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;

    if (editingId) {
      const tool = tools.find(t => t.id === editingId);
      if (tool) { tool.name = name; tool.url = url; tool.emoji = emoji; }
    } else {
      tools.push({ id: genId(), name, url, emoji });
    }

    await save();
    render();
    closeModal();
    window.showToast(editingId ? 'Tool updated!' : 'Tool added!');
  }

  async function deleteTool(id) {
    tools = tools.filter(t => t.id !== id);
    await save();
    render();
    window.showToast('Tool removed.');
  }

  async function init() {
    const r = await Storage.get(['aiTools']);
    tools = r.aiTools || Storage.DEFAULT_SETTINGS.aiTools;
    render();

    if (addBtn) addBtn.addEventListener('click', openAdd);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (saveBtn) saveBtn.addEventListener('click', saveTool);
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  }

  return { init };
})();

window.AITools = AITools;
