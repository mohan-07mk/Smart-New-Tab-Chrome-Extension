/* =============================================
   ANALYTICS.JS — Usage Analytics & Charts
   ============================================= */

const Analytics = (() => {
  const modal = document.getElementById('analytics-modal');
  const openBtn = document.getElementById('btn-analytics');
  const closeBtn = document.getElementById('close-analytics');
  let dailyChartInst = null;
  let weeklyChartInst = null;

  // Tab switching
  function setupTabs() {
    document.querySelectorAll('.atab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.atab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        document.querySelectorAll('.analytics-panel').forEach(p => {
          p.classList.remove('active');
          p.classList.add('hidden');
        });
        const target = document.getElementById(`analytics-${tab.dataset.tab}`);
        if (target) { target.classList.remove('hidden'); target.classList.add('active'); }
        renderTab(tab.dataset.tab);
      });
    });
  }

  async function getAnalyticsData() {
    const r = await Storage.get(['analytics']);
    return r.analytics || {};
  }

  async function renderTab(tab) {
    const data = await getAnalyticsData();

    if (tab === 'daily') renderDaily(data);
    else if (tab === 'weekly') renderWeekly(data);
    else if (tab === 'sites') renderSites(data);
  }

  function getTodayKey() {
    return new Date().toISOString().slice(0, 10);
  }

  function getWeekKeys() {
    const keys = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      keys.push(d.toISOString().slice(0, 10));
    }
    return keys;
  }

  function renderDaily(data) {
    const today = getTodayKey();
    const todayData = data[today] || {};
    const sites = Object.entries(todayData).sort((a, b) => b[1] - a[1]).slice(0, 8);

    const labels = sites.map(([domain]) => domain.replace('www.', '').slice(0, 15));
    const values = sites.map(([, secs]) => parseFloat((secs / 60).toFixed(1)));

    const canvas = document.getElementById('daily-chart');
    if (!canvas) return;

    if (dailyChartInst) dailyChartInst.destroy();
    dailyChartInst = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels.length ? labels : ['No data yet'],
        datasets: [{
          label: 'Minutes',
          data: values.length ? values : [0],
          backgroundColor: labels.map((_, i) => `hsl(${220 + i * 25}, 70%, 60%)`),
          borderRadius: 8,
          borderSkipped: false,
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: ctx => `${ctx.parsed.y} min` } }
        },
        scales: {
          x: { ticks: { color: '#aaa', font: { size: 11 } }, grid: { display: false } },
          y: { ticks: { color: '#aaa', font: { size: 11 } }, grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true }
        }
      }
    });

    // Productivity score
    const totalMinutes = values.reduce((a, b) => a + b, 0);
    const PRODUCTIVE = ['github.com', 'stackoverflow.com', 'notion.so', 'figma.com', 'docs.google', 'sheets.google'];
    const productiveMin = sites
      .filter(([d]) => PRODUCTIVE.some(p => d.includes(p)))
      .reduce((a, [, s]) => a + s / 60, 0);
    const score = totalMinutes > 0 ? Math.min(100, Math.round((productiveMin / totalMinutes) * 100)) : 0;

    const scoreEl = document.getElementById('productivity-score');
    if (scoreEl) {
      const color = score >= 60 ? '#10b981' : score >= 30 ? '#f59e0b' : '#ef4444';
      scoreEl.innerHTML = `
        <div style="font-size:0.85rem; opacity:0.6; margin-bottom:4px">Today's Productivity Score</div>
        <div style="font-size:2.5rem; font-weight:800; color:${color}">${score}%</div>
        <div style="font-size:0.8rem; opacity:0.5">${totalMinutes.toFixed(1)} total minutes online today</div>
      `;
    }
  }

  function renderWeekly(data) {
    const keys = getWeekKeys();
    const dayLabels = keys.map(k => {
      const d = new Date(k);
      return d.toLocaleDateString('en', { weekday: 'short' });
    });
    const values = keys.map(k => {
      const dayData = data[k] || {};
      const total = Object.values(dayData).reduce((a, b) => a + b, 0);
      return parseFloat((total / 60).toFixed(1));
    });

    const canvas = document.getElementById('weekly-chart');
    if (!canvas) return;
    if (weeklyChartInst) weeklyChartInst.destroy();

    weeklyChartInst = new Chart(canvas, {
      type: 'line',
      data: {
        labels: dayLabels,
        datasets: [{
          label: 'Minutes',
          data: values,
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99,102,241,0.15)',
          fill: true,
          tension: 0.4,
          pointBackgroundColor: '#6366f1',
          pointRadius: 5,
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#aaa' }, grid: { display: false } },
          y: { ticks: { color: '#aaa' }, grid: { color: 'rgba(255,255,255,0.05)' }, beginAtZero: true }
        }
      }
    });
  }

  function renderSites(data) {
    const el = document.getElementById('top-sites-list');
    if (!el) return;

    // Aggregate all time
    const totals = {};
    Object.values(data).forEach(dayData => {
      Object.entries(dayData).forEach(([site, secs]) => {
        totals[site] = (totals[site] || 0) + secs;
      });
    });

    const sorted = Object.entries(totals).sort((a, b) => b[1] - a[1]).slice(0, 10);
    const maxSecs = sorted[0]?.[1] || 1;

    if (sorted.length === 0) {
      el.innerHTML = '<div style="text-align:center; opacity:0.5; padding:20px">No usage data yet.<br>Browse some sites to see analytics.</div>';
      return;
    }

    el.innerHTML = sorted.map(([site, secs]) => {
      const pct = Math.round((secs / maxSecs) * 100);
      const mins = Math.round(secs / 60);
      const hours = (secs / 3600).toFixed(1);
      const display = secs >= 3600 ? `${hours}h` : `${mins}m`;
      return `
        <div class="site-item">
          <span class="site-name">${site.replace('www.', '').slice(0, 20)}</span>
          <div class="site-bar-wrap">
            <div class="site-bar" style="width:${pct}%"></div>
          </div>
          <span class="site-time">${display}</span>
        </div>
      `;
    }).join('');
  }

  function open() {
    if (modal) modal.classList.remove('hidden');
    renderTab('daily');
    setupTabs();
  }

  function close() {
    if (modal) modal.classList.add('hidden');
  }

  function init() {
    if (openBtn) openBtn.addEventListener('click', open);
    if (closeBtn) closeBtn.addEventListener('click', close);
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) close(); });
    // Set chart defaults for dark theme
    if (window.Chart) {
      Chart.defaults.color = '#9ca3af';
      Chart.defaults.font.family = 'Inter, sans-serif';
    }
  }

  return { init };
})();

window.Analytics = Analytics;
