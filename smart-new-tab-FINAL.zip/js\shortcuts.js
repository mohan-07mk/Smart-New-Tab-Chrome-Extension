/* =============================================
   SHORTCUTS.JS — Shortcut Cards (Bottom Bar)
   ============================================= */

const Shortcuts = (() => {
  let shortcuts = [];
  let editingId = null;
  let dragSrcIdx = null;

  const gridEl = document.getElementById('shortcuts-grid');
  const modal = document.getElementById('shortcut-modal');
  const modalTitle = document.getElementById('shortcut-modal-title');
  const nameInput = document.getElementById('shortcut-name');
  const urlInput = document.getElementById('shortcut-url');
  const emojiInput = document.getElementById('shortcut-emoji');
  const saveBtn = document.getElementById('shortcut-save-btn');
  const addBtn = document.getElementById('btn-add-shortcut');
  const closeBtn = document.getElementById('close-shortcut-modal');

  function genId() { return 's' + Date.now() + Math.random().toString(36).slice(2,7); }
  async function save() { await Storage.set({ shortcuts }); }

  function getFavicon(url) {
    try {
      const domain = new URL(url).hostname;
      return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
    } catch { return null; }
  }

  function escHtml(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  function render() {
    if (!gridEl) return;
    gridEl.innerHTML = '';

    shortcuts.forEach((sc, idx) => {
      const card = document.createElement('div');
      card.className = 'shortcut-card ripple-btn';
      card.draggable = true;
      card.dataset.idx = idx;

      const favicon = getFavicon(sc.url);
      const iconContent = sc.emoji
        ? `<span style="font-size:1.3rem">${sc.emoji}</span>`
        : favicon
          ? `<img src="${favicon}" width="28" height="28" style="border-radius:6px" onerror="this.style.display='none';this.nextSibling.style.display='block'"><span style="display:none;font-size:1.3rem">🌐</span>`
          : `<span style="font-size:1.3rem">🌐</span>`;

      card.innerHTML = `
        <div class="shortcut-icon">${iconContent}</div>
        <span class="shortcut-name">${escHtml(sc.name)}</span>
        <div class="shortcut-actions">
          <button class="sc-action-btn sc-edit" data-id="${sc.id}" title="Edit">✏</button>
          <button class="sc-action-btn sc-del" data-id="${sc.id}" title="Delete">✕</button>
        </div>
      `;

      // Click to open URL
      card.addEventListener('click', (e) => {
        if (e.target.closest('.shortcut-actions')) return;
        window.open(sc.url, '_blank');
      });

      // Drag & drop reorder
      card.addEventListener('dragstart', (e) => {
        dragSrcIdx = idx;
        card.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
      });
      card.addEventListener('dragend', () => {
        card.classList.remove('dragging');
        gridEl.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'));
      });
      card.addEventListener('dragover', (e) => {
        e.preventDefault(); e.dataTransfer.dropEffect = 'move';
        card.classList.add('drag-over');
      });
      card.addEventListener('dragleave', () => card.classList.remove('drag-over'));
      card.addEventListener('drop', async (e) => {
        e.preventDefault();
        card.classList.remove('drag-over');
        if (dragSrcIdx === null || dragSrcIdx === idx) return;
        const moved = shortcuts.splice(dragSrcIdx, 1)[0];
        shortcuts.splice(idx, 0, moved);
        dragSrcIdx = null;
        await save();
        render();
      });

      gridEl.appendChild(card);
    });

    // Edit/Delete buttons
    gridEl.querySelectorAll('.sc-edit').forEach(btn => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openEdit(btn.dataset.id); });
    });
    gridEl.querySelectorAll('.sc-del').forEach(btn => {
      btn.addEventListener('click', async (e) => { e.stopPropagation(); await deleteShortcut(btn.dataset.id); });
    });
  }

  function openAdd() {
    editingId = null;
    if (modalTitle) modalTitle.textContent = 'Add Shortcut';
    if (nameInput) nameInput.value = '';
    if (urlInput) urlInput.value = '';
    if (emojiInput) emojiInput.value = '';
    if (modal) modal.classList.remove('hidden');
    nameInput?.focus();
  }

  function openEdit(id) {
    const sc = shortcuts.find(s => s.id === id);
    if (!sc) return;
    editingId = id;
    if (modalTitle) modalTitle.textContent = 'Edit Shortcut';
    if (nameInput) nameInput.value = sc.name;
    if (urlInput) urlInput.value = sc.url;
    if (emojiInput) emojiInput.value = sc.emoji || '';
    if (modal) modal.classList.remove('hidden');
    nameInput?.focus();
  }

  function closeModal() { if (modal) modal.classList.add('hidden'); }

  async function saveShortcut() {
    const name = nameInput?.value.trim();
    let url = urlInput?.value.trim();
    const emoji = emojiInput?.value.trim();
    if (!name || !url) { window.showToast('Name and URL are required.'); return; }
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;

    if (editingId) {
      const sc = shortcuts.find(s => s.id === editingId);
      if (sc) { sc.name = name; sc.url = url; sc.emoji = emoji; }
    } else {
      shortcuts.push({ id: genId(), name, url, emoji });
    }

    await save();
    render();
    closeModal();
    window.showToast(editingId ? 'Shortcut updated!' : 'Shortcut added!');
  }

  async function deleteShortcut(id) {
    shortcuts = shortcuts.filter(s => s.id !== id);
    await save();
    render();
    window.showToast('Shortcut removed.');
  }

  async function init() {
    const r = await Storage.get(['shortcuts']);
    shortcuts = r.shortcuts || Storage.DEFAULT_SETTINGS.shortcuts;
    render();

    if (addBtn) addBtn.addEventListener('click', openAdd);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (saveBtn) saveBtn.addEventListener('click', saveShortcut);
    if (modal) modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

    // Enter key in modal inputs
    [nameInput, urlInput, emojiInput].forEach(inp => {
      inp?.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveShortcut(); });
    });
  }

  return { init };
})();

window.Shortcuts = Shortcuts;
