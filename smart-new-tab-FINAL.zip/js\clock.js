/* =============================================
   CLOCK.JS — Digital Clock Widget
   ============================================= */

const Clock = (() => {
  let format = 12;
  let interval = null;

  const timeEl = document.getElementById('clock-time');
  const ampmEl = document.getElementById('clock-ampm');
  const dateEl = document.getElementById('clock-date');
  const greetingEl = document.getElementById('clock-greeting');
  const formatBtn = document.getElementById('clock-format-toggle');

  const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  const GREETINGS = {
    morning: ['Good morning! ☀️', 'Rise and shine! 🌅', 'Hello, sunshine! 🌞'],
    afternoon: ['Good afternoon! 🌤', 'Hope your day is going well! 😊', 'Keep it up! 💪'],
    evening: ['Good evening! 🌆', 'Wind down time! 🌇', 'Almost there! 🌉'],
    night: ['Good night! 🌙', 'Burning the midnight oil? 🕯️', 'Sweet dreams ahead! ⭐'],
  };

  function getGreeting() {
    const h = new Date().getHours();
    if (h >= 5 && h < 12) return randomFrom(GREETINGS.morning);
    if (h >= 12 && h < 17) return randomFrom(GREETINGS.afternoon);
    if (h >= 17 && h < 21) return randomFrom(GREETINGS.evening);
    return randomFrom(GREETINGS.night);
  }

  function randomFrom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  function pad(n) { return String(n).padStart(2, '0'); }

  function tick() {
    const now = new Date();
    let h = now.getHours();
    const m = now.getMinutes();
    const s = now.getSeconds();
    let ampm = '';

    if (format === 12) {
      ampm = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12;
      ampmEl.style.display = '';
    } else {
      ampmEl.style.display = 'none';
    }

    if (timeEl) timeEl.textContent = `${pad(h)}:${pad(m)}:${pad(s)}`;
    if (ampmEl) ampmEl.textContent = ampm;

    // Date
    const day = DAYS[now.getDay()];
    const date = now.getDate();
    const month = MONTHS[now.getMonth()];
    const year = now.getFullYear();
    if (dateEl) dateEl.textContent = `${day}, ${date} ${month} ${year}`;

    // Greeting (update greeting text in header too)
    const greetingHeader = document.getElementById('greeting-text');
    if (greetingHeader) {
      const h24 = now.getHours();
      if (h24 >= 5 && h24 < 12) greetingHeader.textContent = 'Good morning,';
      else if (h24 >= 12 && h24 < 17) greetingHeader.textContent = 'Good afternoon,';
      else if (h24 >= 17 && h24 < 21) greetingHeader.textContent = 'Good evening,';
      else greetingHeader.textContent = 'Good night,';
    }
  }

  async function init() {
    const r = await Storage.get(['clockFormat']);
    format = r.clockFormat || 12;
    if (formatBtn) formatBtn.textContent = format === 12 ? '12H' : '24H';

    tick();
    interval = setInterval(tick, 1000);

    // Greeting (changes once per load)
    if (greetingEl) greetingEl.textContent = getGreeting();

    // Format toggle
    if (formatBtn) {
      formatBtn.addEventListener('click', async () => {
        format = format === 12 ? 24 : 12;
        formatBtn.textContent = format === 12 ? '12H' : '24H';
        await Storage.set({ clockFormat: format });
        tick();
      });
    }
  }

  return { init };
})();

window.Clock = Clock;
