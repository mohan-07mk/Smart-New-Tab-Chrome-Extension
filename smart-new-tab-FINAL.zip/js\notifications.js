/* =============================================
   NOTIFICATIONS.JS — Reminders & Desktop Notifications
   ============================================= */

const Notifications = (() => {
  let reminders = [];
  let timers = {};

  const listEl = document.getElementById('reminder-list');
  const addBtn = document.getElementById('btn-add-reminder');
  const modal = document.getElementById('reminder-modal');
  const closeBtn = document.getElementById('close-reminder-modal');
  const nameInput = document.getElementById('reminder-name');
  const intervalSelect = document.getElementById('reminder-interval');
  const saveBtn = document.getElementById('reminder-save-btn');

  function genId() { return 'r' + Date.now() + Math.random().toString(36).slice(2,7); }

  async function save() { await Storage.set({ reminders }); }

  function requestPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }

  function fireNotification(title, body, tag = 'snt') {
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, { body, icon: '../assets/icons/icon48.png', tag });
      } catch (e) {
        // Chrome extensions use chrome.notifications instead
        if (typeof chrome !== 'undefined' && chrome.notifications) {
          chrome.notifications.create(tag + '-' + Date.now(), {
            type: 'basic',
            iconUrl: '../assets/icons/icon48.png',
            title,
            message: body,
          });
        }
      }
    } else if (typeof chrome !== 'undefined' && chrome.notifications) {
      chrome.notifications.create(tag + '-' + Date.now(), {
        type: 'basic',
        iconUrl: 'assets/icons/icon48.png',
        title,
        message: body,
      });
    }
  }

  function scheduleReminder(reminder) {
    clearTimeout(timers[reminder.id]);
    const ms = reminder.interval * 60 * 1000;
    timers[reminder.id] = setTimeout(function fire() {
      fireNotification(`⏰ ${reminder.name}`, `Reminder: ${reminder.name}`, reminder.id);
      window.showToast(`⏰ Reminder: ${reminder.name}`);
      timers[reminder.id] = setTimeout(fire, ms);
    }, ms);
  }

  function cancelReminder(id) {
    clearTimeout(timers[id]);
    delete timers[id];
  }

  function renderList() {
    if (!listEl) return;
    listEl.innerHTML = '';
    if (reminders.length === 0) {
      listEl.innerHTML = '<div style="opacity:0.5; font-size:0.85rem; text-align:center; padding:8px">No reminders set.</div>';
      return;
    }
    reminders.forEach(r => {
      const item = document.createElement('div');
      item.className = 'reminder-item';
      item.innerHTML = `
        <span class="reminder-name">${escHtml(r.name)}</span>
        <span class="reminder-interval">Every ${r.interval} min</span>
        <button class="reminder-del" data-id="${r.id}" title="Delete">🗑</button>
      `;
      item.querySelector('.reminder-del').addEventListener('click', async () => {
        await deleteReminder(r.id);
      });
      listEl.appendChild(item);
    });
  }

  function escHtml(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  function openModal() { if (modal) modal.classList.remove('hidden'); nameInput?.focus(); }
  function closeModal() { if (modal) modal.classList.add('hidden'); }

  async function addReminder() {
    const name = nameInput?.value.trim();
    const interval = parseInt(intervalSelect?.value) || 30;
    if (!name) { window.showToast('Enter a reminder name.'); return; }

    const r = { id: genId(), name, interval, active: true };
    reminders.push(r);
    await save();
    scheduleReminder(r);
    renderList();
    closeModal();
    if (nameInput) nameInput.value = '';
    window.showToast('Reminder set: ' + name);
  }

  async function deleteReminder(id) {
    cancelReminder(id);
    reminders = reminders.filter(r => r.id !== id);
    await save();
    renderList();
    window.showToast('Reminder removed.');
  }

  async function init() {
    requestPermission();
    const r = await Storage.get(['reminders']);
    reminders = r.reminders || [];

    // Schedule all active reminders
    reminders.forEach(rem => { if (rem.active !== false) scheduleReminder(rem); });
    renderList();

    if (addBtn) addBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (saveBtn) saveBtn.addEventListener('click', addReminder);
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  }

  return { init, fireNotification, renderList };
})();

window.Notifications = Notifications;
