/* =============================================
   TODO.JS — To-Do List Widget
   ============================================= */

const Todo = (() => {
  let todos = [];
  let filter = 'all';
  let editingId = null;

  const listEl = document.getElementById('todo-list');
  const inputEl = document.getElementById('todo-input');
  const addBtn = document.getElementById('todo-add-btn');
  const countEl = document.getElementById('todo-count');
  const clearDoneBtn = document.getElementById('todo-clear-done');

  function genId() { return 't' + Date.now() + Math.random().toString(36).slice(2, 7); }

  async function save() {
    await Storage.set({ todos });
  }

  function render() {
    if (!listEl) return;
    listEl.innerHTML = '';

    const filtered = filter === 'all' ? todos
      : filter === 'active' ? todos.filter(t => !t.done)
      : todos.filter(t => t.done);

    if (filtered.length === 0) {
      listEl.innerHTML = `<li style="text-align:center; opacity:0.4; padding:20px; font-size:0.85rem">
        ${filter === 'done' ? 'No completed tasks yet.' : 'All caught up! Add a task.'}
      </li>`;
    }

    filtered.forEach(todo => {
      const li = document.createElement('li');
      li.className = 'todo-item' + (todo.done ? ' done' : '');
      li.dataset.id = todo.id;

      li.innerHTML = `
        <div class="todo-checkbox ${todo.done ? 'checked' : ''}" data-id="${todo.id}"></div>
        <span class="todo-text">${escapeHtml(todo.text)}</span>
        <button class="todo-edit-btn" data-id="${todo.id}" title="Edit">✏️</button>
        <button class="todo-del-btn" data-id="${todo.id}" title="Delete">🗑</button>
      `;
      listEl.appendChild(li);
    });

    const active = todos.filter(t => !t.done).length;
    if (countEl) countEl.textContent = `${active} task${active !== 1 ? 's' : ''} left`;
  }

  function escapeHtml(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  async function addTodo() {
    const text = inputEl?.value.trim();
    if (!text) return;

    if (editingId) {
      const todo = todos.find(t => t.id === editingId);
      if (todo) todo.text = text;
      editingId = null;
      if (addBtn) { addBtn.textContent = '+'; addBtn.style.background = ''; }
    } else {
      todos.unshift({ id: genId(), text, done: false, created: Date.now() });
    }

    if (inputEl) inputEl.value = '';
    await save();
    render();
  }

  async function toggleDone(id) {
    const todo = todos.find(t => t.id === id);
    if (todo) { todo.done = !todo.done; await save(); render(); }
  }

  async function deleteTodo(id) {
    todos = todos.filter(t => t.id !== id);
    await save();
    render();
  }

  function editTodo(id) {
    const todo = todos.find(t => t.id === id);
    if (todo && inputEl) {
      inputEl.value = todo.text;
      inputEl.focus();
      editingId = id;
      if (addBtn) { addBtn.textContent = '✓'; addBtn.style.background = 'var(--success)'; }
    }
  }

  async function clearDone() {
    todos = todos.filter(t => !t.done);
    await save();
    render();
  }

  async function init() {
    const r = await Storage.get(['todos']);
    todos = r.todos || [];
    render();

    if (addBtn) addBtn.addEventListener('click', addTodo);
    if (inputEl) inputEl.addEventListener('keydown', e => { if (e.key === 'Enter') addTodo(); });

    if (clearDoneBtn) clearDoneBtn.addEventListener('click', clearDone);

    // Filter buttons
    document.querySelectorAll('.todo-filter').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.todo-filter').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filter = btn.dataset.filter;
        render();
      });
    });

    // Delegated events on list
    if (listEl) {
      listEl.addEventListener('click', (e) => {
        const id = e.target.dataset.id;
        if (!id) return;
        if (e.target.classList.contains('todo-checkbox')) toggleDone(id);
        if (e.target.classList.contains('todo-del-btn')) deleteTodo(id);
        if (e.target.classList.contains('todo-edit-btn')) editTodo(id);
      });
    }
  }

  return { init };
})();

window.Todo = Todo;
