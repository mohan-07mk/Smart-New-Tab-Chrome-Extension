/* =============================================
   STORAGE.JS — Chrome Storage API Wrapper
   ============================================= */

const Storage = (() => {
  const DEFAULT_SETTINGS = {
    // Profile
    userName: 'User',
    // Theme
    theme: 'dark',
    bgColor: '',
    bgImage: '',
    accentColor: '#6366f1',
    customColors: false,
    // Clock
    clockFormat: 12,
    // Weather
    weatherUnit: 'metric',
    weatherApiKey: 'YOUR_OPENWEATHERMAP_API_KEY',
    weatherLocation: null,
    // Widgets visibility
    widgets: {
      clock: true,
      weather: true,
      pomodoro: true,
      timer: true,
      todo: true,
      water: true,
    },
    // Widget order (drag-to-reorder)
    widgetOrder: ['clock','weather','pomodoro','timer','todo','water'],
    // Pomodoro
    pomodoroWork: 25,
    pomodoroBreak: 5,
    // Todo
    todos: [],
    // Water
    waterCount: 0,
    waterGoal: 8,
    waterInterval: 30,
    waterLastReset: '',
    // Shortcuts
    shortcuts: [
      { id: 's1', name: 'YouTube', url: 'https://youtube.com', emoji: '📺' },
      { id: 's2', name: 'Gmail', url: 'https://mail.google.com', emoji: '📧' },
      { id: 's3', name: 'WhatsApp', url: 'https://web.whatsapp.com', emoji: '💬' },
      { id: 's4', name: 'ChatGPT', url: 'https://chat.openai.com', emoji: '🤖' },
      { id: 's5', name: 'GitHub', url: 'https://github.com', emoji: '🐙' },
    ],
    // AI Tools
    aiTools: [
      { id: 'ai1', name: 'ChatGPT', url: 'https://chat.openai.com', emoji: '🧠' },
      { id: 'ai2', name: 'Gemini', url: 'https://gemini.google.com', emoji: '♊' },
      { id: 'ai3', name: 'Perplexity', url: 'https://www.perplexity.ai', emoji: '🔍' },
      { id: 'ai4', name: 'Grammarly', url: 'https://www.grammarly.com', emoji: '✍️' },
      { id: 'ai5', name: 'Notion AI', url: 'https://www.notion.so', emoji: '📝' },
      { id: 'ai6', name: 'Claude', url: 'https://claude.ai', emoji: '🌟' },
    ],
    // Search
    recentSearches: [],
    // Reminders
    reminders: [
      { id: 'r1', name: 'Drink Water', interval: 30, active: true },
    ],
    // Analytics
    analytics: {},
  };

  function get(keys) {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get(keys, (result) => resolve(result));
      } else {
        // Fallback to localStorage for development
        const result = {};
        const keyArr = Array.isArray(keys) ? keys : [keys];
        keyArr.forEach(k => {
          const val = localStorage.getItem('snt_' + k);
          if (val !== null) {
            try { result[k] = JSON.parse(val); } catch { result[k] = val; }
          }
        });
        resolve(result);
      }
    });
  }

  function set(data) {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.set(data, resolve);
      } else {
        Object.entries(data).forEach(([k, v]) => {
          localStorage.setItem('snt_' + k, JSON.stringify(v));
        });
        resolve();
      }
    });
  }

  function remove(keys) {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.remove(keys, resolve);
      } else {
        const keyArr = Array.isArray(keys) ? keys : [keys];
        keyArr.forEach(k => localStorage.removeItem('snt_' + k));
        resolve();
      }
    });
  }

  async function getAll() {
    const keys = Object.keys(DEFAULT_SETTINGS);
    const stored = await get(keys);
    // Merge defaults
    const result = { ...DEFAULT_SETTINGS };
    keys.forEach(k => {
      if (stored[k] !== undefined) result[k] = stored[k];
    });
    return result;
  }

  async function clear() {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      return new Promise(resolve => chrome.storage.local.clear(resolve));
    } else {
      const keys = Object.keys(DEFAULT_SETTINGS);
      keys.forEach(k => localStorage.removeItem('snt_' + k));
      return Promise.resolve();
    }
  }

  function exportSettings(settings) {
    const json = JSON.stringify(settings, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'smart-newtab-settings.json';
    a.click(); URL.revokeObjectURL(url);
  }

  function importSettings(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const data = JSON.parse(e.target.result);
          await set(data);
          resolve(data);
        } catch (err) { reject(err); }
      };
      reader.readAsText(file);
    });
  }

  return { get, set, remove, getAll, clear, exportSettings, importSettings, DEFAULT_SETTINGS };
})();

window.Storage = Storage;
