/* =============================================
   THEMES.JS — Theme & Background Management
   Custom Color changes the FULL theme palette
   ============================================= */

const Themes = (() => {
  const body = document.getElementById('app-body');
  const bgLayer = document.getElementById('bg-layer');
  let currentWallpaperDataUrl = null;
  let customStyleEl = null; // <style> tag for custom color overrides

  const THEME_BG = {
    dark: '',
    light: '',
    gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)',
    ocean: 'radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%)',
    forest: 'linear-gradient(180deg, #0f2027, #203a2f, #2c5364)',
    sunset: 'linear-gradient(180deg, #0d0221 0%, #461220 30%, #e9692c 70%, #f5af19 100%)',
  };

  /* ---- Colour math helpers ---- */
  function hexToRgb(hex) {
    const r = parseInt(hex.slice(1,3),16);
    const g = parseInt(hex.slice(3,5),16);
    const b = parseInt(hex.slice(5,7),16);
    return {r,g,b};
  }

  function luminance({r,g,b}) {
    return (0.299*r + 0.587*g + 0.114*b) / 255;
  }

  function darken(hex, amt) {
    let {r,g,b} = hexToRgb(hex);
    r = Math.max(0, r - amt); g = Math.max(0, g - amt); b = Math.max(0, b - amt);
    return '#' + [r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
  }

  function lighten(hex, amt) {
    let {r,g,b} = hexToRgb(hex);
    r = Math.min(255,r+amt); g = Math.min(255,g+amt); b = Math.min(255,b+amt);
    return '#' + [r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
  }

  function hexAlpha(hex, alpha) {
    const {r,g,b} = hexToRgb(hex);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  /**
   * Generate a full CSS variable palette from a single background hex color.
   * If the color is dark → dark theme palette; if light → light palette.
   */
  function buildPaletteCSS(bgHex, accentHex) {
    const rgb = hexToRgb(bgHex);
    const lum = luminance(rgb);
    const isDark = lum < 0.45;

    const bg      = bgHex;
    const bgDark  = isDark ? darken(bgHex, 20)  : darken(bgHex, 30);
    const surface = isDark ? lighten(bgHex, 18) : lighten(bgHex, 40);
    const navBg   = isDark ? hexAlpha(bgDark, .85) : hexAlpha(lighten(bgHex,50),.88);
    const textPrimary   = isDark ? '#f0f0ff' : '#1a1a2e';
    const textSecondary = isDark ? 'rgba(240,240,255,.6)' : 'rgba(26,26,46,.6)';
    const glassBg       = isDark ? 'rgba(255,255,255,.06)' : 'rgba(255,255,255,.5)';
    const glassBorder   = isDark ? 'rgba(255,255,255,.1)' : 'rgba(0,0,0,.1)';
    const widgetBg      = isDark ? hexAlpha(bgDark, .88) : hexAlpha(lighten(bgHex,55),.85);
    const overlay       = isDark ? hexAlpha(bgDark, .55) : hexAlpha(bgHex, .2);
    const accent        = accentHex || '#6366f1';
    const shadowGlow    = hexAlpha(accent, .4);

    return `
      #app-body {
        --bg-base:        ${bg};
        --bg-overlay:     ${overlay};
        --nav-bg:         ${navBg};
        --surface:        ${surface}f0;
        --text-primary:   ${textPrimary};
        --text-secondary: ${textSecondary};
        --accent:         ${accent};
        --accent-2:       ${lighten(accent,30)};
        --success:        #10b981;
        --warning:        #f59e0b;
        --danger:         #ef4444;
        --glass-bg:       ${glassBg};
        --glass-border:   ${glassBorder};
        --widget-bg:      ${widgetBg};
        --shadow-glow:    0 0 24px ${shadowGlow};
      }
      #bg-layer { background: ${bg} !important; }
    `;
  }

  function applyCustomColors(bgHex, accentHex) {
    if (!customStyleEl) {
      customStyleEl = document.createElement('style');
      customStyleEl.id = 'custom-color-style';
      document.head.appendChild(customStyleEl);
    }
    customStyleEl.textContent = buildPaletteCSS(bgHex, accentHex);
    // Also update the bg-layer
    if (!currentWallpaperDataUrl) {
      bgLayer.style.backgroundImage = '';
      bgLayer.style.background = bgHex;
    }
  }

  function removeCustomColors() {
    if (customStyleEl) { customStyleEl.textContent = ''; }
    if (!currentWallpaperDataUrl) {
      bgLayer.style.background = '';
      bgLayer.style.backgroundImage = '';
    }
  }

  function applyTheme(theme) {
    removeCustomColors(); // clear any custom CSS overrides
    body.className = body.className.replace(/\btheme-\S+/g, '').trim();
    body.classList.add(`theme-${theme}`);
    if (!currentWallpaperDataUrl) {
      if (THEME_BG[theme]) {
        bgLayer.style.backgroundImage = '';
        bgLayer.style.background = THEME_BG[theme];
      } else {
        bgLayer.style.background = '';
        bgLayer.style.backgroundImage = '';
      }
    }
  }

  function applyBgColor(color) {
    if (color && !currentWallpaperDataUrl) {
      bgLayer.style.backgroundImage = '';
      bgLayer.style.background = color;
    }
  }

  function applyWallpaper(dataUrl) {
    if (!dataUrl) return;
    currentWallpaperDataUrl = dataUrl;
    bgLayer.style.background = 'none';
    bgLayer.style.backgroundImage = `url("${dataUrl}")`;
    bgLayer.style.backgroundSize = 'cover';
    bgLayer.style.backgroundPosition = 'center';
    bgLayer.style.backgroundRepeat = 'no-repeat';
    const preview = document.getElementById('wallpaper-preview');
    const previewWrap = document.getElementById('wallpaper-preview-wrap');
    if (preview) preview.src = dataUrl;
    if (previewWrap) previewWrap.classList.remove('hidden');
  }

  function removeWallpaper() {
    currentWallpaperDataUrl = null;
    bgLayer.style.backgroundImage = '';
    const previewWrap = document.getElementById('wallpaper-preview-wrap');
    if (previewWrap) previewWrap.classList.add('hidden');
    Storage.get(['theme', 'bgColor', 'accentColor', 'customColors']).then(r => {
      if (r.customColors) {
        applyCustomColors(r.bgColor || '#0d0d1a', r.accentColor || '#6366f1');
      } else if (r.bgColor) {
        applyBgColor(r.bgColor);
      } else {
        applyTheme(r.theme || 'dark');
      }
    });
  }

  async function init() {
    const settings = await Storage.getAll();
    applyTheme(settings.theme || 'dark');
    if (settings.bgImage) {
      applyWallpaper(settings.bgImage);
    } else if (settings.customColors && settings.bgColor) {
      applyCustomColors(settings.bgColor, settings.accentColor || '#6366f1');
    } else if (settings.bgColor) {
      applyBgColor(settings.bgColor);
    }
  }

  function setupSettingsListeners() {
    // Theme preset buttons
    document.querySelectorAll('.theme-opt').forEach(btn => {
      btn.addEventListener('click', async () => {
        document.querySelectorAll('.theme-opt').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const theme = btn.dataset.theme;
        // Switching to a preset clears custom colors
        await Storage.set({ theme, customColors: false });
        applyTheme(theme);
        // Reset pickers to defaults
        const bgPicker = document.getElementById('setting-bg-color');
        const acPicker = document.getElementById('setting-accent-color');
        if (bgPicker) bgPicker.value = '#0f0f1a';
        if (acPicker) acPicker.value = '#6366f1';
        window.showToast('Theme applied: ' + btn.textContent.trim());
      });
    });

    // Background color picker — changes full palette
    const colorPicker = document.getElementById('setting-bg-color');
    const accentPicker = document.getElementById('setting-accent-color');

    function applyColorPickers() {
      const bg = colorPicker ? colorPicker.value : '#0d0d1a';
      const accent = accentPicker ? accentPicker.value : '#6366f1';
      // Deselect all theme presets
      document.querySelectorAll('.theme-opt').forEach(b => b.classList.remove('active'));
      applyCustomColors(bg, accent);
      Storage.set({ bgColor: bg, accentColor: accent, customColors: true });
    }

    if (colorPicker) {
      colorPicker.addEventListener('input', applyColorPickers);
    }
    if (accentPicker) {
      accentPicker.addEventListener('input', applyColorPickers);
    }

    // Wallpaper upload
    const wallpaperInput = document.getElementById('wallpaper-upload');
    if (wallpaperInput) {
      wallpaperInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) {
          window.showToast('Please select a valid image file.');
          return;
        }
        window.showToast('Loading wallpaper...');
        const reader = new FileReader();
        reader.onload = async (ev) => {
          const dataUrl = ev.target.result;
          if (!dataUrl) { window.showToast('Failed to load image.'); return; }
          applyWallpaper(dataUrl);
          await Storage.set({ bgImage: dataUrl });
          window.showToast('✅ Wallpaper set!');
        };
        reader.onerror = () => window.showToast('Failed to read file.');
        reader.readAsDataURL(file);
        wallpaperInput.value = '';
      });
    }

    // Download wallpaper
    const downloadBtn = document.getElementById('btn-download-wallpaper');
    if (downloadBtn) {
      downloadBtn.addEventListener('click', async () => {
        const r = await Storage.get(['bgImage']);
        if (r.bgImage) {
          const a = document.createElement('a');
          a.href = r.bgImage;
          a.download = 'my-wallpaper.png';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        } else {
          window.showToast('No custom wallpaper set.');
        }
      });
    }

    // Remove wallpaper
    const removeBtn = document.getElementById('btn-remove-wallpaper');
    if (removeBtn) {
      removeBtn.addEventListener('click', async () => {
        removeWallpaper();
        await Storage.set({ bgImage: '' });
        window.showToast('Wallpaper removed.');
      });
    }
  }

  return { init, applyTheme, applyBgColor, applyCustomColors, applyWallpaper, removeWallpaper, setupSettingsListeners };
})();

window.Themes = Themes;
