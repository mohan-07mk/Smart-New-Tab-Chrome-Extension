/* =============================================
   POMODORO.JS — Pomodoro Productivity Timer
   ============================================= */

const Pomodoro = (() => {
  let workDuration = 25 * 60;
  let breakDuration = 5 * 60;
  let timeLeft = workDuration;
  let totalTime = workDuration;
  let isRunning = false;
  let isBreak = false;
  let session = 1;
  let totalSessions = 4;
  let interval = null;

  const timeEl = document.getElementById('pomo-time');
  const labelEl = document.getElementById('pomo-label');
  const sessionEl = document.getElementById('pomo-session');
  const ringEl = document.getElementById('pomo-ring-progress');
  const startBtn = document.getElementById('pomo-start');
  const resetBtn = document.getElementById('pomo-reset');
  const skipBtn = document.getElementById('pomo-skip');

  const CIRCUMFERENCE = 326.73; // 2 * π * 52

  function pad(n) { return String(n).padStart(2, '0'); }

  function updateDisplay() {
    const m = Math.floor(timeLeft / 60);
    const s = timeLeft % 60;
    if (timeEl) timeEl.textContent = `${pad(m)}:${pad(s)}`;

    const progress = 1 - timeLeft / totalTime;
    const offset = CIRCUMFERENCE * progress;
    if (ringEl) {
      ringEl.style.strokeDashoffset = CIRCUMFERENCE - offset;
      ringEl.classList.toggle('break', isBreak);
    }
    if (labelEl) labelEl.textContent = isBreak ? '☕ Break Time' : '💻 Focus Time';
    if (sessionEl) sessionEl.textContent = `Session ${session} / ${totalSessions}`;
  }

  function startTimer() {
    if (isRunning) return;
    isRunning = true;
    if (startBtn) startBtn.textContent = '⏸ Pause';
    document.getElementById('widget-pomodoro')?.classList.add('running');

    interval = setInterval(() => {
      if (timeLeft <= 0) {
        clearInterval(interval);
        isRunning = false;
        handleCycleEnd();
        return;
      }
      timeLeft--;
      updateDisplay();
    }, 1000);
  }

  function pauseTimer() {
    clearInterval(interval);
    isRunning = false;
    if (startBtn) startBtn.textContent = '▶ Start';
    document.getElementById('widget-pomodoro')?.classList.remove('running');
  }

  function resetTimer() {
    clearInterval(interval);
    isRunning = false;
    isBreak = false;
    session = 1;
    timeLeft = workDuration;
    totalTime = workDuration;
    if (startBtn) startBtn.textContent = '▶ Start';
    document.getElementById('widget-pomodoro')?.classList.remove('running');
    updateDisplay();
  }

  function skipPhase() {
    clearInterval(interval);
    isRunning = false;
    handleCycleEnd();
  }

  function handleCycleEnd() {
    document.getElementById('widget-pomodoro')?.classList.remove('running');

    if (!isBreak) {
      // Work done → break
      isBreak = true;
      timeLeft = breakDuration;
      totalTime = breakDuration;
      window.showToast('🍅 Pomodoro complete! Take a break.');
      Notifications.fireNotification('Pomodoro Done!', 'Great work! Take a short break. ☕', 'pomodoro');
    } else {
      // Break done → next session
      isBreak = false;
      session = session >= totalSessions ? 1 : session + 1;
      timeLeft = workDuration;
      totalTime = workDuration;
      window.showToast('☕ Break over! Time to focus.');
      Notifications.fireNotification('Break Over!', 'Back to work! You can do it. 💪', 'pomodoro');
    }
    if (startBtn) startBtn.textContent = '▶ Start';
    updateDisplay();
  }

  async function init() {
    const r = await Storage.get(['pomodoroWork', 'pomodoroBreak']);
    workDuration = (r.pomodoroWork || 25) * 60;
    breakDuration = (r.pomodoroBreak || 5) * 60;
    timeLeft = workDuration;
    totalTime = workDuration;
    updateDisplay();

    if (startBtn) {
      startBtn.addEventListener('click', () => {
        if (isRunning) pauseTimer();
        else startTimer();
      });
    }
    if (resetBtn) resetBtn.addEventListener('click', resetTimer);
    if (skipBtn) skipBtn.addEventListener('click', skipPhase);
  }

  function updateDurations(work, brk) {
    workDuration = work * 60;
    breakDuration = brk * 60;
    resetTimer();
  }

  return { init, updateDurations };
})();

window.Pomodoro = Pomodoro;
