/* =============================================
   SETTINGS.JS — Settings Panel Logic
   ============================================= */

const Settings = (() => {
  const panel = document.getElementById('settings-panel');
  const openBtn = document.getElementById('btn-settings');
  const closeBtn = document.getElementById('close-settings');

  function open() {
    if (panel) {
      panel.classList.remove('hidden');
      // Use rAF to allow CSS transition to play
      requestAnimationFrame(() => panel.classList.add('open'));
    }
    Widgets.renderToggles();
    Notifications.renderList();
  }

  function close() {
    if (panel) {
      panel.classList.remove('open');
      setTimeout(() => panel.classList.add('hidden'), 400);
    }
  }

  async function loadCurrentValues() {
    const settings = await Storage.getAll();

    // Name
    const nameEl = document.getElementById('setting-name');
    if (nameEl) nameEl.value = settings.userName || '';

    // Theme
    document.querySelectorAll('.theme-opt').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.theme === settings.theme);
    });

    // BG color
    const colorEl = document.getElementById('setting-bg-color');
    if (colorEl && settings.bgColor) colorEl.value = settings.bgColor;

    // Accent color
    const accentEl = document.getElementById('setting-accent-color');
    if (accentEl && settings.accentColor) accentEl.value = settings.accentColor;

    // Wallpaper preview
    if (settings.bgImage) {
      const preview = document.getElementById('wallpaper-preview');
      const previewWrap = document.getElementById('wallpaper-preview-wrap');
      if (preview) preview.src = settings.bgImage;
      if (previewWrap) previewWrap.classList.remove('hidden');
    }

    // Weather API key
    const weatherKeyEl = document.getElementById('setting-weather-key');
    if (weatherKeyEl) weatherKeyEl.value = settings.weatherApiKey !== 'YOUR_OPENWEATHERMAP_API_KEY' ? settings.weatherApiKey : '';

    // Pomodoro settings
    const pomoWork = document.getElementById('pomo-work-setting');
    const pomoBreak = document.getElementById('pomo-break-setting');
    if (pomoWork) pomoWork.value = settings.pomodoroWork || 25;
    if (pomoBreak) pomoBreak.value = settings.pomodoroBreak || 5;
  }

  async function setupListeners() {
    // Name input
    const nameEl = document.getElementById('setting-name');
    if (nameEl) {
      nameEl.addEventListener('input', async () => {
        const name = nameEl.value.trim() || 'User';
        await Storage.set({ userName: name });
        // Update all greeting name elements
        document.querySelectorAll('#greeting-name').forEach(el => el.textContent = name);
      });
    }

    // Weather API key
    const weatherKeyEl = document.getElementById('setting-weather-key');
    if (weatherKeyEl) {
      weatherKeyEl.addEventListener('change', async () => {
        const key = weatherKeyEl.value.trim();
        await Storage.set({ weatherApiKey: key || 'YOUR_OPENWEATHERMAP_API_KEY' });
        if (Weather && key) Weather.updateApiKey(key);
        window.showToast('Weather API key saved.');
      });
    }

    // Pomodoro settings
    const pomoWork = document.getElementById('pomo-work-setting');
    const pomoBreak = document.getElementById('pomo-break-setting');
    const applyPomo = async () => {
      const work = parseInt(pomoWork?.value) || 25;
      const brk = parseInt(pomoBreak?.value) || 5;
      await Storage.set({ pomodoroWork: work, pomodoroBreak: brk });
      if (Pomodoro) Pomodoro.updateDurations(work, brk);
      window.showToast('Pomodoro settings saved.');
    };
    if (pomoWork) pomoWork.addEventListener('change', applyPomo);
    if (pomoBreak) pomoBreak.addEventListener('change', applyPomo);

    // Export settings
    const exportBtn = document.getElementById('btn-export-settings');
    if (exportBtn) {
      exportBtn.addEventListener('click', async () => {
        const settings = await Storage.getAll();
        Storage.exportSettings(settings);
        window.showToast('Settings exported!');
      });
    }

    // Import settings
    const importInput = document.getElementById('import-settings-file');
    if (importInput) {
      importInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        try {
          await Storage.importSettings(file);
          window.showToast('Settings imported! Reloading...');
          setTimeout(() => window.location.reload(), 1200);
        } catch {
          window.showToast('Import failed. Invalid file.');
        }
      });
    }

    // Reset dashboard
    const resetBtn = document.getElementById('btn-reset-dashboard');
    if (resetBtn) {
      resetBtn.addEventListener('click', async () => {
        if (confirm('Reset all dashboard settings? This cannot be undone.')) {
          await Storage.clear();
          window.showToast('Dashboard reset. Reloading...');
          setTimeout(() => window.location.reload(), 1200);
        }
      });
    }
  }

  async function init() {
    await loadCurrentValues();

    if (openBtn) openBtn.addEventListener('click', open);
    if (closeBtn) closeBtn.addEventListener('click', close);

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (panel && panel.classList.contains('open') &&
          !panel.contains(e.target) && e.target !== openBtn && !openBtn?.contains(e.target)) {
        close();
      }
    });

    await setupListeners();
    Themes.setupSettingsListeners();
  }

  return { init, open, close };
})();

window.Settings = Settings;
