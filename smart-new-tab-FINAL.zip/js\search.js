/* =============================================
   SEARCH.JS — Smart Google Search Bar with
   Instant Shortcut / Site Suggestions
   ============================================= */

const Search = (() => {
  const MAX_HISTORY = 10;
  let recentSearches = [];
  let isListening = false;
  let recognition = null;
  let allSuggestions = []; // built from shortcuts + AI tools + popular sites

  const input = document.getElementById('search-input');
  const submitBtn = document.getElementById('btn-search-submit');
  const voiceBtn = document.getElementById('btn-voice-search');
  const suggestionsEl = document.getElementById('search-suggestions');

  // Popular built-in suggestions
  const POPULAR_SITES = [
    { text: 'YouTube', url: 'https://youtube.com', icon: '📺' },
    { text: 'Gmail', url: 'https://mail.google.com', icon: '📧' },
    { text: 'Google Drive', url: 'https://drive.google.com', icon: '📁' },
    { text: 'WhatsApp Web', url: 'https://web.whatsapp.com', icon: '💬' },
    { text: 'Instagram', url: 'https://instagram.com', icon: '📸' },
    { text: 'Twitter / X', url: 'https://x.com', icon: '🐦' },
    { text: 'Facebook', url: 'https://facebook.com', icon: '👥' },
    { text: 'Netflix', url: 'https://netflix.com', icon: '🎬' },
    { text: 'GitHub', url: 'https://github.com', icon: '🐙' },
    { text: 'ChatGPT', url: 'https://chat.openai.com', icon: '🧠' },
    { text: 'Claude AI', url: 'https://claude.ai', icon: '🌟' },
    { text: 'Gemini', url: 'https://gemini.google.com', icon: '♊' },
    { text: 'Reddit', url: 'https://reddit.com', icon: '🤖' },
    { text: 'Amazon', url: 'https://amazon.com', icon: '🛒' },
    { text: 'Google Maps', url: 'https://maps.google.com', icon: '🗺️' },
    { text: 'Spotify', url: 'https://spotify.com', icon: '🎵' },
    { text: 'Wikipedia', url: 'https://wikipedia.org', icon: '📖' },
    { text: 'LinkedIn', url: 'https://linkedin.com', icon: '💼' },
    { text: 'Notion', url: 'https://notion.so', icon: '📝' },
    { text: 'Figma', url: 'https://figma.com', icon: '🎨' },
    { text: 'Stack Overflow', url: 'https://stackoverflow.com', icon: '💡' },
    { text: 'Perplexity AI', url: 'https://perplexity.ai', icon: '🔍' },
  ];

  async function buildSuggestions() {
    // Load shortcuts and AI tools from storage
    const r = await Storage.get(['shortcuts', 'aiTools']);
    const shortcuts = r.shortcuts || [];
    const aiTools = r.aiTools || [];

    allSuggestions = [];

    // Add user shortcuts
    shortcuts.forEach(sc => {
      allSuggestions.push({
        text: sc.name,
        url: sc.url,
        icon: sc.emoji || '🔗',
        type: 'shortcut'
      });
    });

    // Add AI tools
    aiTools.forEach(t => {
      if (!allSuggestions.find(s => s.url === t.url)) {
        allSuggestions.push({
          text: t.name,
          url: t.url,
          icon: t.emoji || '🤖',
          type: 'aitool'
        });
      }
    });

    // Add popular sites (avoid duplicates by URL)
    POPULAR_SITES.forEach(site => {
      if (!allSuggestions.find(s => s.url === site.url)) {
        allSuggestions.push({ ...site, type: 'site' });
      }
    });
  }

  async function save() { await Storage.set({ recentSearches }); }

  function doSearch(query, url = null) {
    if (!query.trim() && !url) return;
    hideSuggestions();
    if (url) {
      window.open(url, '_blank');
      return;
    }
    // Save to history
    recentSearches = [query, ...recentSearches.filter(s => s !== query)].slice(0, MAX_HISTORY);
    save();
    // Navigate
    const href = /^https?:\/\//i.test(query) || /^[\w-]+\.[\w-]+(\.[\\w-]+)*(\/.*)?$/.test(query)
      ? (query.startsWith('http') ? query : 'https://' + query)
      : `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    window.location.href = href;
  }

  function escHtml(str) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
  }

  function highlightMatch(text, query) {
    if (!query) return escHtml(text);
    const idx = text.toLowerCase().indexOf(query.toLowerCase());
    if (idx === -1) return escHtml(text);
    return escHtml(text.slice(0, idx))
      + `<strong style="color:var(--accent)">${escHtml(text.slice(idx, idx + query.length))}</strong>`
      + escHtml(text.slice(idx + query.length));
  }

  function showSuggestions(value) {
    if (!suggestionsEl) return;
    const trimmed = value.trim().toLowerCase();
    let items = [];

    if (!trimmed) {
      // Show recent searches when input is focused but empty
      const recentItems = recentSearches.slice(0, 5).map(s => ({
        text: s, icon: '🕐', type: 'recent', url: null
      }));
      // Also show first 4 shortcuts as quick access
      const quickItems = allSuggestions.slice(0, 4).map(s => ({
        ...s, type: 'quick'
      }));
      items = [...recentItems, ...quickItems];
    } else {
      // Instant match from shortcuts + popular sites
      const siteMatches = allSuggestions
        .filter(s => s.text.toLowerCase().includes(trimmed) || (s.url && s.url.toLowerCase().includes(trimmed)))
        .slice(0, 5)
        .map(s => ({ ...s }));

      // Recent searches match
      const recentMatches = recentSearches
        .filter(s => s.toLowerCase().includes(trimmed))
        .slice(0, 3)
        .map(s => ({ text: s, icon: '🕐', type: 'recent', url: null }));

      // "Search Google for..." always first
      const searchItem = { text: value, icon: '🔍', type: 'search', url: null };

      items = [searchItem, ...siteMatches, ...recentMatches];
    }

    if (items.length === 0) { hideSuggestions(); return; }

    suggestionsEl.innerHTML = items.map(item => {
      const label = trimmed ? highlightMatch(item.text, trimmed) : escHtml(item.text);
      const badge = item.type === 'shortcut' ? '<span class="sug-badge sug-badge-sc">shortcut</span>'
        : item.type === 'aitool' ? '<span class="sug-badge sug-badge-ai">AI</span>'
        : item.type === 'quick' ? '<span class="sug-badge sug-badge-sc">shortcut</span>'
        : '';
      const clearBtn = item.type === 'recent'
        ? `<span class="suggestion-clear" data-clear="${escHtml(item.text)}">✕</span>` : '';
      const urlPreview = item.url && item.type !== 'search'
        ? `<span class="sug-url">${escHtml(new URL(item.url).hostname.replace('www.',''))}</span>` : '';
      return `
        <div class="suggestion-item" data-text="${escHtml(item.text)}" data-url="${item.url ? escHtml(item.url) : ''}" data-type="${item.type}">
          <span class="sug-icon">${item.icon}</span>
          <span class="sug-label">${label}</span>
          ${urlPreview}
          ${badge}
          ${clearBtn}
        </div>
      `;
    }).join('');

    // Click handlers
    suggestionsEl.querySelectorAll('.suggestion-item').forEach(el => {
      el.addEventListener('mousedown', (e) => {
        // mousedown fires before blur so we can intercept
        const clearText = e.target.dataset.clear;
        if (clearText) {
          e.preventDefault();
          recentSearches = recentSearches.filter(s => s !== clearText);
          save();
          showSuggestions(input?.value || '');
          return;
        }
        e.preventDefault();
        const url = el.dataset.url;
        const text = el.dataset.text;
        doSearch(text, url || null);
      });
    });

    suggestionsEl.classList.remove('hidden');
  }

  function hideSuggestions() {
    if (suggestionsEl) suggestionsEl.classList.add('hidden');
  }

  function setupVoiceSearch() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      if (voiceBtn) voiceBtn.style.display = 'none';
      return;
    }
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      isListening = true;
      if (voiceBtn) voiceBtn.classList.add('listening');
      if (input) input.placeholder = '🎤 Listening...';
    };
    recognition.onend = () => {
      isListening = false;
      if (voiceBtn) voiceBtn.classList.remove('listening');
      if (input) input.placeholder = 'Search Google or type a URL...';
    };
    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      if (input) input.value = transcript;
      doSearch(transcript);
    };
    recognition.onerror = () => {
      isListening = false;
      if (voiceBtn) voiceBtn.classList.remove('listening');
      if (input) input.placeholder = 'Search Google or type a URL...';
      window.showToast('Voice not recognized. Try again.');
    };

    if (voiceBtn) {
      voiceBtn.addEventListener('click', () => {
        if (isListening) { recognition.stop(); return; }
        try { recognition.start(); } catch (e) { window.showToast('Voice search unavailable.'); }
      });
    }
  }

  async function init() {
    const r = await Storage.get(['recentSearches']);
    recentSearches = r.recentSearches || [];
    await buildSuggestions();

    if (input) {
      input.addEventListener('input', (e) => showSuggestions(e.target.value));
      input.addEventListener('focus', () => showSuggestions(input.value));
      input.addEventListener('blur', () => setTimeout(hideSuggestions, 150));
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') doSearch(input.value);
        if (e.key === 'Escape') { hideSuggestions(); input.blur(); }
        // Arrow key navigation
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          const items = suggestionsEl?.querySelectorAll('.suggestion-item');
          if (!items || items.length === 0) return;
          let focused = suggestionsEl.querySelector('.suggestion-item.focused');
          if (focused) focused.classList.remove('focused');
          let idx = focused ? [...items].indexOf(focused) : -1;
          idx = e.key === 'ArrowDown' ? Math.min(idx + 1, items.length - 1) : Math.max(idx - 1, 0);
          items[idx].classList.add('focused');
          input.value = items[idx].dataset.text;
        }
      });
    }

    if (submitBtn) submitBtn.addEventListener('click', () => doSearch(input?.value || ''));

    document.addEventListener('click', (e) => {
      if (!e.target.closest('.search-container')) hideSuggestions();
    });

    setupVoiceSearch();
  }

  return { init, buildSuggestions };
})();

window.Search = Search;
