/* =============================================
   BACKGROUND.JS — Service Worker
   Handles: Analytics tracking, Alarms, Notifications
   ============================================= */

// ---- Tab Time Tracking ----
let activeTab = null;
let activeStart = null;

function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getDomain(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace('www.', '');
  } catch { return null; }
}

async function saveTrack(domain, seconds) {
  if (!domain || seconds < 1) return;
  const today = getTodayKey();
  const result = await chrome.storage.local.get(['analytics']);
  const analytics = result.analytics || {};
  if (!analytics[today]) analytics[today] = {};
  analytics[today][domain] = (analytics[today][domain] || 0) + seconds;
  await chrome.storage.local.set({ analytics });
}

async function flushActiveTab() {
  if (activeTab && activeStart) {
    const secs = Math.round((Date.now() - activeStart) / 1000);
    await saveTrack(activeTab, secs);
  }
  activeTab = null;
  activeStart = null;
}

// ---- Tab listeners ----
chrome.tabs.onActivated.addListener(async (info) => {
  await flushActiveTab();
  try {
    const tab = await chrome.tabs.get(info.tabId);
    const domain = getDomain(tab.url);
    if (domain && !domain.includes('newtab') && domain !== 'chrome') {
      activeTab = domain;
      activeStart = Date.now();
    }
  } catch (e) { /* ignore */ }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (currentTab?.id === tabId) {
    await flushActiveTab();
    const domain = getDomain(tab.url);
    if (domain && !domain.includes('newtab') && domain !== 'chrome') {
      activeTab = domain;
      activeStart = Date.now();
    }
  }
});

chrome.tabs.onRemoved.addListener(async () => {
  await flushActiveTab();
});

// ---- Window focus tracking ----
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await flushActiveTab();
  } else {
    try {
      const [tab] = await chrome.tabs.query({ active: true, windowId });
      if (tab) {
        const domain = getDomain(tab.url);
        if (domain && !domain.includes('newtab') && domain !== 'chrome') {
          activeTab = domain;
          activeStart = Date.now();
        }
      }
    } catch (e) { /* ignore */ }
  }
});

// ---- Periodic flush every 60s ----
chrome.alarms.create('flush-track', { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'flush-track') {
    await flushActiveTab();
    // Restart tracking if still active
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab) {
        const domain = getDomain(tab.url);
        if (domain && !domain.includes('newtab') && domain !== 'chrome') {
          activeTab = domain;
          activeStart = Date.now();
        }
      }
    } catch (e) { /* ignore */ }
  }

  // Water reminder alarm
  if (alarm.name === 'water-reminder') {
    const result = await chrome.storage.local.get(['waterCount', 'waterGoal']);
    const count = result.waterCount || 0;
    const goal = result.waterGoal || 8;
    chrome.notifications.create('water-' + Date.now(), {
      type: 'basic',
      iconUrl: 'assets/icons/icon48.png',
      title: '💧 Drink Water!',
      message: `You've had ${count}/${goal} glasses today. Stay hydrated!`,
    });
  }

  // Custom reminders
  const result = await chrome.storage.local.get(['reminders']);
  const reminders = result.reminders || [];
  const reminder = reminders.find(r => `reminder-${r.id}` === alarm.name);
  if (reminder) {
    chrome.notifications.create('rem-' + Date.now(), {
      type: 'basic',
      iconUrl: 'assets/icons/icon48.png',
      title: `⏰ ${reminder.name}`,
      message: `Reminder: ${reminder.name}`,
    });
  }
});

// ---- Install listener ----
chrome.runtime.onInstalled.addListener(() => {
  console.log('[Smart New Tab] Extension installed.');
  // Create periodic tracking alarm
  chrome.alarms.create('flush-track', { periodInMinutes: 1 });
});
