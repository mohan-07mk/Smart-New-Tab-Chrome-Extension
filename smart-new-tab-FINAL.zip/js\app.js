/* =============================================
   APP.JS — Main Application Controller
   ============================================= */

(async function initApp() {
  // ---- Toast ----
  const toastEl = document.getElementById('toast');
  let toastTimer = null;
  window.showToast = function(msg, duration = 3000) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.remove('hidden');
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, duration);
  };

  // ---- Ripple Effect on all .ripple-btn elements ----
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.ripple-btn');
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    const ripple = document.createElement('span');
    ripple.className = 'ripple-wave';
    ripple.style.cssText = `width:${size}px;height:${size}px;left:${x}px;top:${y}px;`;
    btn.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  }, true);

  // ---- Load user name ----
  const { userName } = await Storage.getAll();
  const greetNameEl = document.getElementById('greeting-name');
  if (greetNameEl) greetNameEl.textContent = userName || 'User';
  const greetNameInlineEl = document.getElementById('greeting-name');
  if (greetNameInlineEl) greetNameInlineEl.textContent = userName || 'User';

  // ---- Hero clock (separate from widget clock) ----
  function updateHeroClock() {
    const now = new Date();
    const h = now.getHours().toString().padStart(2,'0');
    const m = now.getMinutes().toString().padStart(2,'0');
    const heroTime = document.getElementById('hero-time');
    if (heroTime) heroTime.textContent = `${h}:${m}`;
    const heroDate = document.getElementById('hero-date');
    if (heroDate) {
      heroDate.textContent = now.toLocaleDateString('en-US', {
        weekday:'long', year:'numeric', month:'long', day:'numeric'
      });
    }
    // Greeting in topnav
    const hour = now.getHours();
    let greet = hour < 12 ? 'Good morning,' : hour < 17 ? 'Good afternoon,' : 'Good evening,';
    const greetEl = document.getElementById('greeting-text');
    if (greetEl) greetEl.textContent = greet;
  }
  updateHeroClock();
  setInterval(updateHeroClock, 30000);

  // ---- Initialize all modules ----
  try { await Themes.init(); } catch(e) { console.error('[Themes]', e); }
  try { await Widgets.init(); } catch(e) { console.error('[Widgets]', e); }
  try { await Clock.init(); } catch(e) { console.error('[Clock]', e); }
  try { await Weather.init(); } catch(e) { console.error('[Weather]', e); }
  try { await Pomodoro.init(); } catch(e) { console.error('[Pomodoro]', e); }
  try { Timer.init(); } catch(e) { console.error('[Timer]', e); }
  try { await Todo.init(); } catch(e) { console.error('[Todo]', e); }
  try { await Water.init(); } catch(e) { console.error('[Water]', e); }
  try { await Shortcuts.init(); } catch(e) { console.error('[Shortcuts]', e); }
  try { await AITools.init(); } catch(e) { console.error('[AITools]', e); }
  try { await Search.init(); } catch(e) { console.error('[Search]', e); }
  try { GoogleHub.init(); } catch(e) { console.error('[GoogleHub]', e); }
  try { Analytics.init(); } catch(e) { console.error('[Analytics]', e); }
  try { await Notifications.init(); } catch(e) { console.error('[Notifications]', e); }
  try { await Settings.init(); } catch(e) { console.error('[Settings]', e); }

  // ---- Analytics modal open button ----
  const analyticsBtn = document.getElementById('btn-analytics');
  if (analyticsBtn) {
    analyticsBtn.addEventListener('click', () => {
      const modal = document.getElementById('analytics-modal');
      if (modal) modal.classList.remove('hidden');
    });
  }

  // ---- Keyboard shortcuts ----
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey && e.key === 'k') || (e.key === '/' && document.activeElement.tagName !== 'INPUT')) {
      e.preventDefault();
      document.getElementById('search-input')?.focus();
    }
    if (e.key === 'Escape') {
      document.querySelectorAll('.panel-overlay:not(.hidden)').forEach(p => p.classList.add('hidden'));
      Settings.close();
    }
  });

  console.log('[Smart New Tab] ✅ All modules loaded.');
})();
