/* =============================================
   TIMER.JS — Countdown Timer & Stopwatch
   ============================================= */

const Timer = (() => {
  let mode = 'countdown'; // 'countdown' or 'stopwatch'
  let running = false;
  let interval = null;
  let elapsed = 0;       // stopwatch ms
  let countdownSecs = 0; // countdown total seconds
  let remaining = 0;     // countdown remaining
  let laps = [];

  const displayEl = document.getElementById('timer-display');
  const inputsEl = document.getElementById('timer-inputs');
  const lapListEl = document.getElementById('lap-list');
  const startBtn = document.getElementById('timer-start');
  const pauseBtn = document.getElementById('timer-pause');
  const resetBtn = document.getElementById('timer-reset');
  const modeBtn = document.getElementById('timer-mode-toggle');
  const hInput = document.getElementById('timer-h');
  const mInput = document.getElementById('timer-m');
  const sInput = document.getElementById('timer-s');

  function pad(n) { return String(n).padStart(2, '0'); }

  function formatMs(ms) {
    const totalS = Math.floor(ms / 1000);
    const h = Math.floor(totalS / 3600);
    const m = Math.floor((totalS % 3600) / 60);
    const s = totalS % 60;
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }

  function formatSecs(secs) {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }

  function updateDisplay() {
    if (!displayEl) return;
    if (mode === 'stopwatch') {
      displayEl.textContent = formatMs(elapsed);
    } else {
      displayEl.textContent = formatSecs(remaining);
    }
  }

  function start() {
    if (running) return;
    if (mode === 'countdown') {
      const h = parseInt(hInput?.value) || 0;
      const m = parseInt(mInput?.value) || 0;
      const s = parseInt(sInput?.value) || 0;
      if (!running && remaining === 0) {
        countdownSecs = h * 3600 + m * 60 + s;
        if (countdownSecs <= 0) { window.showToast('Set a duration first.'); return; }
        remaining = countdownSecs;
      }
      if (inputsEl) inputsEl.style.display = 'none';
      running = true;
      if (startBtn) { startBtn.disabled = true; startBtn.textContent = '▶ Running'; }
      if (pauseBtn) pauseBtn.disabled = false;

      interval = setInterval(() => {
        remaining--;
        updateDisplay();
        if (remaining <= 0) {
          clearInterval(interval);
          running = false;
          if (startBtn) { startBtn.disabled = false; startBtn.textContent = '▶ Start'; }
          if (pauseBtn) pauseBtn.disabled = true;
          playBeep();
          window.showToast('⏰ Timer complete!');
          Notifications.fireNotification('Timer Done!', 'Your countdown is complete! ⏰', 'timer');
        }
      }, 1000);
    } else {
      // Stopwatch
      running = true;
      if (startBtn) { startBtn.textContent = '▶ Running'; startBtn.disabled = true; }
      if (pauseBtn) pauseBtn.disabled = false;
      const startTime = Date.now() - elapsed;
      interval = setInterval(() => {
        elapsed = Date.now() - startTime;
        updateDisplay();
      }, 100);
    }
  }

  function pause() {
    clearInterval(interval);
    running = false;
    if (startBtn) { startBtn.disabled = false; startBtn.textContent = '▶ Resume'; }
    if (pauseBtn) pauseBtn.disabled = true;
    // For stopwatch, add lap
    if (mode === 'stopwatch') addLap();
  }

  function reset() {
    clearInterval(interval);
    running = false;
    elapsed = 0;
    remaining = 0;
    laps = [];
    if (startBtn) { startBtn.disabled = false; startBtn.textContent = '▶ Start'; }
    if (pauseBtn) pauseBtn.disabled = true;
    if (lapListEl) { lapListEl.innerHTML = ''; lapListEl.classList.add('hidden'); }
    if (inputsEl && mode === 'countdown') inputsEl.style.display = '';
    updateDisplay();
  }

  function addLap() {
    if (mode !== 'stopwatch') return;
    laps.push(elapsed);
    if (lapListEl) {
      lapListEl.classList.remove('hidden');
      const item = document.createElement('div');
      item.className = 'lap-item';
      item.textContent = `Lap ${laps.length}: ${formatMs(elapsed)}`;
      lapListEl.prepend(item);
    }
  }

  function switchMode() {
    reset();
    mode = mode === 'countdown' ? 'stopwatch' : 'countdown';
    if (modeBtn) modeBtn.textContent = mode === 'countdown' ? 'Stopwatch' : 'Countdown';
    if (inputsEl) inputsEl.style.display = mode === 'countdown' ? '' : 'none';
    updateDisplay();
  }

  function playBeep() {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);
      osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 1.5);
    } catch (e) { /* Audio not available */ }
  }

  function init() {
    updateDisplay();
    if (startBtn) startBtn.addEventListener('click', start);
    if (pauseBtn) pauseBtn.addEventListener('click', pause);
    if (resetBtn) resetBtn.addEventListener('click', reset);
    if (modeBtn) modeBtn.addEventListener('click', switchMode);
  }

  return { init };
})();

window.Timer = Timer;
